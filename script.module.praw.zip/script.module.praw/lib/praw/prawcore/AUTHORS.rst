prawcore is written and maintained by Bryce Boe and various contributors:

Maintainers
===========

- Bryce Boe <bbzbryce@gmail.com> `@bboe <https://github.com/bboe>`_


Contributors
============

- nmtake `@nmtake <https://github.com/nmtake>`_
- Add "Name <email (optional)> and github profile link" above this line.
