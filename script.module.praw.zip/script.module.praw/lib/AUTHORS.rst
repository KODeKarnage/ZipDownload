Author/Maintainer
=================

- Bryce Boe <bbzbryce@gmail.com> `@bboe <https://github.com/bboe>`_


Team Members
============

- Ethan Dalool <edalool@yahoo.com> `@voussoir <https://github.com/voussoir>`_


Documentation Contributors
==========================

- Dale Cudmore <dalecudmore@gmail.com> `@DCuddies <https://github.com/DCuddies>`_
- Zhifu Ge <zhifu@me.com> `@zhifuge <https://github.com/zhifuge>`_
- diceroll123 `@diceroll123 <https://github.com/diceroll123>`_
- Mike Wohlrab `@D0cR3d <https://github.com/D0cR3d>`_
- Add "Name <email (optional)> and github profile link" above this line.


Source Contributors
===================

- William McKinnerney <me@williammck.net> `@williammck <https://github.com/williammck>`_
- Katharine Jarmul <katharine@kjamistan.com> `@kjam <https://github.com/kjam>`_
- nmtake `@nmtake <https://github.com/nmtake>`_
- Levi Roth <levimroth@gmail.com> `@leviroth <https://github.com/leviroth>`_
- Keith Diedrick <diedrickke@gmail.com> `@darthkedrik <https://github.com/darthkedrik>`_
- Add "Name <email (optional)> and github profile link" above this line.
